export interface IDispatchEventMethod {
  dispatchEvent(event: Event): boolean;
}
