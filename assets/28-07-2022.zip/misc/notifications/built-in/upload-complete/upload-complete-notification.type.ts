import { INotification } from '../../notification.type';

export type IUploadCompleteNotification = INotification<'upload-complete', void>;

