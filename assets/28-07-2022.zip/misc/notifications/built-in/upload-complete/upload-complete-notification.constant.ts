import { createUploadCompleteNotification } from './create-upload-complete-notification';
import { IUploadCompleteNotification } from './upload-complete-notification.type';

export const STATIC_UPLOAD_COMPLETE_NOTIFICATION: IUploadCompleteNotification = createUploadCompleteNotification();
