export const UPLOAD_COMPLETE_NOTIFICATION_NAME = 'upload-complete';
