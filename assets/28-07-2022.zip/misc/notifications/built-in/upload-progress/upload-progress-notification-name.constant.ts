export const UPLOAD_PROGRESS_NOTIFICATION_NAME = 'upload-progress';
