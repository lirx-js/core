export const CLOSE_NOTIFICATION_NAME = 'close';
