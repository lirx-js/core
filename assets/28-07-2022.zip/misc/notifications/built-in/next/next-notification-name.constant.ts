export const NEXT_NOTIFICATION_NAME = 'next';
