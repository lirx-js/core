export const OPEN_NOTIFICATION_NAME = 'open';
