export function passthrough<GValue>(value: GValue): GValue {
  return value;
}
