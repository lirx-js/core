export function tuple<GItems extends any[]>(...items: GItems): GItems {
  return items;
}
