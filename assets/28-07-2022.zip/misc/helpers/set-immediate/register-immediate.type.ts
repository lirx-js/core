export interface IRegisterImmediate {
  (handle: number): void;
}
