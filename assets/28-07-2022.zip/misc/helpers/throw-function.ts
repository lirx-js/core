export function throwFunction(
  error: unknown,
): never {
  throw error;
}
