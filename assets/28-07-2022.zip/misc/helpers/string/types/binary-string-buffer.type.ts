export type IBinaryStringBuffer = Uint8Array;
