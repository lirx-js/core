export type IUTF8EncodedStringBuffer = Uint8Array;

