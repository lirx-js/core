export type IReadonlyUTF8EncodedStringBuffer = Readonly<Uint8Array>;

