export const TIMEOUT_ERROR_NAME = 'TimeoutError';

export type ITimeoutErrorName = typeof TIMEOUT_ERROR_NAME;
