export const REFERENCE_ERROR_NAME = 'ReferenceError';
