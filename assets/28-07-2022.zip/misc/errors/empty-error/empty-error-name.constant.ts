export const EMPTY_ERROR_NAME = 'EmptyError';

export type IEmptyErrorName = typeof EMPTY_ERROR_NAME;
