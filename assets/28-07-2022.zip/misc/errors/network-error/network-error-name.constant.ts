export const NETWORK_ERROR_NAME = 'NetworkError';

export type INetworkErrorName = typeof NETWORK_ERROR_NAME;
