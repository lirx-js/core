export const ABORT_ERROR_NAME = 'AbortError';

export type IAbortErrorName = typeof ABORT_ERROR_NAME;
