export const LOCK_ERROR_NAME = 'LockError';

export type ILockErrorName = typeof LOCK_ERROR_NAME;
