export interface IProgress {
  readonly loaded: number;
  readonly total: number;
}

