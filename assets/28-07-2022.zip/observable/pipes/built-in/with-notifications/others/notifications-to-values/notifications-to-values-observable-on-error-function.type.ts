export interface INotificationsToValuesObservableOnErrorFunction {
  (
    error: any,
  ): void;
}
