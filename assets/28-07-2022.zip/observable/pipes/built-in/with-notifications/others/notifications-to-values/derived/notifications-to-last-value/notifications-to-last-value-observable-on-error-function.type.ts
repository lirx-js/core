import { INotificationsToValuesObservableOnErrorFunction } from '../../notifications-to-values-observable-on-error-function.type';

export type INotificationsToLastValueObservableOnErrorFunction = INotificationsToValuesObservableOnErrorFunction;
