import { IDefaultNotificationsUnion } from '../../../../../../../misc/notifications/default-notifications-union.type';

export type IFinallyObservableOutNotifications<GInNextValue> = IDefaultNotificationsUnion<GInNextValue>;
