export { rejectedObservable as rejected$$ } from './rejected-observable';


