export { debounceFrameObservablePipe as debounceFrame$$$ } from './debounce-frame-observable-pipe';


