export { debounceFrameObservable as debounceFrame$$ } from './debounce-frame-observable';


