export { throttleTimeObservable as throttleTime$$ } from './throttle-time-observable';


