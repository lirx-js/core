export interface IThrottleTimeObservablePipeOptions {
  leading?: boolean; // (default: true)
  trailing?: boolean; // (default: true)
}
