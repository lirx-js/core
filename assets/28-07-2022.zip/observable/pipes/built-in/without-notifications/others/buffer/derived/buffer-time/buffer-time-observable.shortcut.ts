export { bufferTimeObservable as bufferTime$$ } from './buffer-time-observable';
export { bufferTimeObservable as bufferT$$ } from './buffer-time-observable';


