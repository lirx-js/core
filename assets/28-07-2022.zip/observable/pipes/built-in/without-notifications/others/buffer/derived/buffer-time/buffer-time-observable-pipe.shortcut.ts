export { bufferTimeObservablePipe as bufferTime$$$ } from './buffer-time-observable-pipe';
export { bufferTimeObservablePipe as bufferT$$$ } from './buffer-time-observable-pipe';


