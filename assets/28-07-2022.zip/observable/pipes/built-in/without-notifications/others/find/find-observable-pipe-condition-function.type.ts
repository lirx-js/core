export interface IFindObservablePipeConditionFunction<GValue> {
  (value: GValue): boolean;
}
