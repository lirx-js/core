export { firstObservable as first$$ } from './first-observable';


