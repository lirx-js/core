export { firstObservablePipe as first$$$ } from './first-observable-pipe';


