export {
  mergeMapSingleObservablePipe as mergeMapSingle$$$,
  mergeMapSingleObservablePipe as mergeMapS$$$,
  mergeMapSingleObservablePipe as switchMapObservablePipe,
  mergeMapSingleObservablePipe as switchMap$$$,
} from './merge-map-single-observable-pipe';


