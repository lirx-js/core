## mergeMapSingleObservablePipe, mergeMapS$$$, switchMapObservablePipe or switchMap$$$

```ts
function mergeMapSingleObservablePipe<GIn, GOut>(
  mapFunction: IMapFunction<GIn, IObservable<GOut>>,
): IObservablePipe<GIn, GOut>
```

This function is a shortcut and optimized version of `mergeMapObservablePipe(mapFunction, 1)`

See [mergeMapObservablePipe](../../merge-map-observable-pipe.md)

The RxJS equivalent is [switchMap](https://rxjs.dev/api/index/function/switchMap)

