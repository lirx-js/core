export {
  mergeMapSingleObservable as mergeMapSingle$$,
  mergeMapSingleObservable as mergeMapS$$,
  mergeMapSingleObservable as switchMapObservable,
  mergeMapSingleObservable as switchMap$$,
} from './merge-map-single-observable';


