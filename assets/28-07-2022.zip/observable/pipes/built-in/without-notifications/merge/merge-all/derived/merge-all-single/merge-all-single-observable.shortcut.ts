export {
  mergeAllSingleObservable as mergeAllSingle$$,
  mergeAllSingleObservable as mergeAllS$$,
  mergeAllSingleObservable as switchAllObservable,
  mergeAllSingleObservable as switchAll$$,
} from './merge-all-single-observable';


