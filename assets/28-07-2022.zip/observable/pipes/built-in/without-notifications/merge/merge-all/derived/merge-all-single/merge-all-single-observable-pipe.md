## mergeAllSingleObservablePipe, mergeAllS$$$, switchAllObservable, or switchAll$$$

```ts
function mergeAllSingleObservablePipe<GValue>(): IObservablePipe<IObservable<GValue>, GValue>
```

This function is a shortcut and optimized version of `mergeAllObservablePipe(1)`

See [mergeAllObservablePipe](../../merge-all-observable-pipe.md)

The RxJS equivalent is [switchAll](https://rxjs.dev/api/index/function/switchAll)

