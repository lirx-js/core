import { IUnsubscribe } from '@lirx/unsubscribe';
import { Callable, noop } from '@lirx/utils';
import { IObservable, IUnsubscribeOfObservable } from '../../../../observable/type/observable.type';
import { IObserver } from '../../../../observer/type/observer.type';
import { SignalContextError } from '../../../error/signal-context-error.class';
import { runSignalWriteModeContext } from '../../../internal/allow-signal-writes/allow-signal-writes-context.private';
import { runSignalContextAndObserveNextChange } from '../../../internal/register-signal/signal-get-called.private';
import { SIGNAL } from '../../../readonly-signal/traits/symbol/signal.symbol';
import {
  ISignalToNotificationsObservableOptions,
  ISignalToObservableOptions,
  ISignalToValueObservableOptions,
} from '../../../readonly-signal/traits/to-observable/signal-to-observable-options.type';
import { PureSignal } from '../../../signal/implementations/class/signal.class';
import { ISignalNotifications } from '../../../signal/types/signal-notifications.type';
import { IPureComputedSignal } from '../../computed-signal.type';
import { IComputedSignalConstructor } from '../../types/computed-signal-constructor.type';
import { IComputedSignalOptions } from '../../types/computed-signal-options.type';
import { IComputedSignalFunction } from '../../types/computed-singal-function.type';

/**
 * Represents a Computed Signal as a class.
 */
export class PureComputedSignal<GValue> implements IPureComputedSignal<GValue> {
  readonly #computedFunction: IComputedSignalFunction<GValue>;
  readonly #signal: PureSignal<GValue>;
  // #pending: boolean;
  #state: 'outdated' | 'updating' | 'fresh' | 'observing';
  #stopObserving: IUnsubscribe;

  constructor(
    computedFunction: IComputedSignalFunction<GValue>,
    options?: IComputedSignalOptions<GValue>,
  ) {
    this.#computedFunction = computedFunction;
    this.#signal = new PureSignal<GValue>(void 0 as GValue, options);
    this.#state = 'outdated';
    this.#stopObserving = noop;
  }

  get [SIGNAL](): unknown {
    return true;
  }

  get(): GValue {
    if (this.#state === 'outdated') {
      this.#state = 'updating';
      this.#runAndObserve((): void => {
        this.#state = 'outdated';
      });
      this.#state = 'fresh';
    } else if (this.#state === 'updating') {
      throw new SignalContextError(`Circular Computed Signal.`);
    }
    return this.#signal.get();
  }

  toObservable(
    options?: ISignalToValueObservableOptions<GValue>,
  ): IObservable<GValue>;
  toObservable(
    options: ISignalToNotificationsObservableOptions,
  ): IObservable<ISignalNotifications<GValue>>;
  toObservable(
    {
      emitCurrentValue = true,
      ...options
    }: ISignalToObservableOptions<GValue> = {},
  ): IObservable<GValue | ISignalNotifications<GValue>> {
    const subscribe: IObservable<GValue | ISignalNotifications<GValue>> = this.#signal.toObservable({
      ...options,
      emitCurrentValue,
    } as any);
    return (emit: IObserver<GValue | ISignalNotifications<GValue>>): IUnsubscribeOfObservable => {
      if (emitCurrentValue && this.#pending) {
        this.#pending = false;
        this.#runLoop();
      }
      return subscribe(emit);
    };
  };

  /**
   * Runs the `computedFunction` into the context of this computed signal.
   *
   * Then sets the resulting value into `#signal`.
   */
  #run(): void {
    runSignalWriteModeContext('allow', (): void => {
      let value!: GValue;
      let errored: boolean = false;
      let error!: unknown;

      try {
        value = runSignalWriteModeContext('forbid', this.#computedFunction);
      } catch (_error: unknown) {
        if (_error instanceof SignalContextError) {
          throw _error;
        } else {
          errored = true;
          error = _error;
        }
      }

      if (errored) {
        this.#signal.throw(error);
      } else {
        this.#signal.set(value);
      }
    });
  }

  #runAndObserve(
    onChange: () => void,
  ): void {
    this.#stopObserving();
    this.#stopObserving = runSignalContextAndObserveNextChange(
      (): void => {
        this.#run();
      },
      onChange,
    );
  }

  // #runAndObserve(
  //   onChange: () => void,
  // ): IUnsubscribe {
  //   this.#stopObserving();
  //   return observeSingleSignalChangeInContext(
  //     (): void => {
  //       this.#run();
  //     },
  //     onChange,
  //   );
  // }

  #runLoop(): void {
    this.#runAndObserve((): void => {
      this.#runLoop();
    });
  }
}

export const ComputedSignal = Callable<typeof PureComputedSignal, IComputedSignalConstructor>(PureComputedSignal, function(this: PureComputedSignal<any>) {
  return this.get();
});
