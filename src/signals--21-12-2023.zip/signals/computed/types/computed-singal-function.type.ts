export interface IComputedSignalFunction<GValue> {
  (): GValue;
}
