import { signal } from '../signal/implementations/function/signal.function';
import { computed } from './implementations/function/computed.function';
import { IReadonlySignal } from '../readonly-signal/readonly-signal.type';

describe('computed', () => {
  test('basic test', () => {
    const a = signal(1);
    expect(a()).toBe(1);

    const b = signal(2);
    expect(b()).toBe(2);

    const c = computed(() => a() + b());
    expect(c()).toBe(3);

    a.set(3);
    expect(c()).toBe(5);

    b.set(1);
    expect(c()).toBe(4);
  });

  test('test glitch-free 1', () => {
    const a = signal(1);
    expect(a()).toBe(1);

    const b = computed(() => a() + 1);
    expect(b()).toBe(2);

    const c = computed(() => b() > a());
    expect(c()).toBe(true);

    a.set(2);
    expect(c()).toBe(true);
    expect(b()).toBe(3);
  });

  test('test glitch-free 2', async () => {
    const counter = signal(0);
    expect(counter()).toBe(0);

    const isEven = computed(() => counter() % 2 === 0);
    expect(isEven()).toBe(true);

    const message = computed(() => `${counter()} is ${isEven() ? 'even' : 'odd'}`);
    expect(message()).toBe('0 is even');

    counter.set(1);
    expect(message()).toBe('1 is odd');

    counter.set(2);
    expect(message()).toBe('2 is even');

    const mockFn = jest.fn();

    message.toObservable({
      emitCurrentValue: true,
      debounce: true,
    })(mockFn);

    counter.set(1);
    counter.set(2);
    counter.set(1);
    counter.set(2);
    expect(message()).toBe('2 is even');
    await Promise.resolve();
    expect(mockFn).toHaveBeenCalledTimes(1);
    expect(mockFn).toHaveBeenCalledWith('2 is even');
  });


  test('test glitch-free 3', () => {
    const seconds = signal(0);
    expect(seconds()).toBe(0);

    const t: IReadonlySignal<number> = computed<number>(() => seconds() > 0 ? (t() + 1) : 0);
    expect(t()).toBe(0);

    seconds.set(1);
    expect(t()).toBe(1);

    seconds.set(2);
    expect(t()).toBe(2);

    seconds.set(1);
    expect(t()).toBe(3);
  });

  test('test non writable', () => {
    const a = signal(1);
    expect(a()).toBe(1);

    const b = computed(() => {
      expect(() => a.set(5)).toThrow();
      return a();
    });

    expect(b()).toBe(1);
  });

  test('test recursive', () => {
    const a = signal(1);
    expect(a()).toBe(1);

    const b = computed(() => {
      return computed(() => a())();
    });

    expect(b()).toBe(1);

    a.set(2);
    expect(a()).toBe(2);
    expect(b()).toBe(2);
  });

});
