import { ISignalFromObservableActivateFunction } from './signal-from-observable.activate.function-definition';

export interface ISignalFromObservableActivateTrait {
  activate: ISignalFromObservableActivateFunction;
}
