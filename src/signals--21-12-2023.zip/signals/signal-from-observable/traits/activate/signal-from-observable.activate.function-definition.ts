export interface ISignalFromObservableActivateFunction {
  (
    active?: boolean,
  ): void;
}
