import { ISignalThrowFunction } from './signal.throw.function-definition';

export interface ISignalThrowTrait {
  readonly throw: ISignalThrowFunction;
}
