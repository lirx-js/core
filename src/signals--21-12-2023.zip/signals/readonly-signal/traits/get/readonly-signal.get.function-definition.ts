export interface IReadonlySignalGetFunction<GValue> {
  (): GValue;
}
