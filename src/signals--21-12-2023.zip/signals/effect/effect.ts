import { IUnsubscribe } from '@lirx/unsubscribe';
import { createMulticastSource } from '../../observer-observable-pair/build-in/source/built-in/multicast-source/create-multicast-source';
import { IMulticastSource } from '../../observer-observable-pair/build-in/source/built-in/multicast-source/multicast-source.type';
import { SignalContextError } from '../error/signal-context-error.class';
import { runSignalWriteModeContext } from '../internal/allow-signal-writes/allow-signal-writes-context.private';
import { Context } from '../internal/context.class.private';
import { runSignalContextAndObserveNextChange } from '../internal/register-signal/signal-get-called.private';
import { IEffectOptions } from './types/effect-options.type';
import { IEffetFunction } from './types/effet-function.type';
import { IUnsubscribeOfEffect } from './types/unsubscribe-of-effect.type';

const EFFECT_CONTEXT = new Context<boolean>(false);

export function effect(
  effectFunction: IEffetFunction,
  {
    signalWriteMode = 'forbid',
  }: IEffectOptions = {},
): IUnsubscribeOfEffect {
  if (EFFECT_CONTEXT.get()) {
    throw new SignalContextError(`Cannot use effect inside effect.`);
  } else {
    return EFFECT_CONTEXT.run(true, (): IUnsubscribeOfEffect => {
      let cleanUpSource: IMulticastSource<void>;

      const run = (
        onChange: () => void,
      ): IUnsubscribe => {
        return runSignalContextAndObserveNextChange(
          (): void => {
            cleanUpSource = createMulticastSource<void>();

            runSignalWriteModeContext(signalWriteMode, (): void => {
              effectFunction(cleanUpSource.subscribe);
            });
          },
          onChange,
        );
      };

      let running: boolean = true;
      let unsubscribeOfRun: IUnsubscribe;

      const unsubscribe = (): void => {
        if (running) {
          running = false;
          unsubscribeOfRun();
          cleanUpSource.emit();
        }
      };

      const runLoop = (): void => {
        unsubscribeOfRun = run((): void => {
          cleanUpSource.emit();
          queueMicrotask((): void => {
            if (running) {
              runLoop();
            }
          });
        });
      };

      runLoop();

      return unsubscribe;
    });
  }

}
