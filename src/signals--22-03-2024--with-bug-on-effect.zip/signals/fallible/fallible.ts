import { UNSET } from '../internal/computed.private';
import {
  FALLIBLE_NODE,
  fallibleAsReadonly,
  fallibleGet,
  fallibleSet,
  fallibleThrow,
  fallibleUpdate,
  IFallibleNode,
} from '../internal/fallible.private';
import { reactiveNodeInit } from '../internal/reactive-node.private';
import { SIGNAL } from '../signal/signal.symbol';
import { IReadonlySignal } from '../signal/types/readonly-signal.type';
import { ISignalUpdateFunctionCallback } from '../signal/types/signal-update-function-callback.type';
import { ICreateFallibleOptions } from './types/create-fallible-options.type';
import { IFallible } from './types/fallible.type';

export function fallible<GValue>(
  initialValue: GValue = UNSET,
  options?: ICreateFallibleOptions<GValue>,
): IFallible<GValue> {
  // preventCreationIfInSignalContext();

  const node: IFallibleNode<GValue> = Object.create(FALLIBLE_NODE);
  reactiveNodeInit(node);
  node.value = initialValue;

  const fallible: IFallible<GValue> = ((): GValue =>
    fallibleGet<GValue>(node)) as IFallible<GValue>;
  fallible[SIGNAL] = node;

  if (options?.equal) {
    node.equal = options.equal;
  }

  fallible.set = (value: GValue): void => fallibleSet<GValue>(node, value);
  fallible.throw = (error: unknown): void => fallibleThrow<GValue>(node, error);
  fallible.update = (updateFunction: ISignalUpdateFunctionCallback<GValue>): void =>
    fallibleUpdate<GValue>(node, updateFunction);
  fallible.asReadonly = (): IReadonlySignal<GValue> => fallibleAsReadonly<GValue>(node);

  return fallible;
}
