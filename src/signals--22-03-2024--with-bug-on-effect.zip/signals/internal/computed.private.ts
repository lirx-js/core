import { EQUAL_FUNCTION_STRICT_EQUAL, IEqualFunction } from '@lirx/utils';
import { IComputationFunction } from '../computed/types/computation-function.type';
import {
  IReactiveNode,
  REACTIVE_NODE,
  reactiveNodeAddSignalChangeListener,
  reactiveNodeDispatchSignalChangeListeners,
} from './reactive-node.private';
import {
  getCurrentSignalChangeContext,
  runSignalChangeContextOnce,
} from './signal-change-context/signal-change-context.private';

export interface IComputedSignalNode<GValue> extends IReactiveNode {
  equal: IEqualFunction<GValue>;
  value: GValue;
  outdated: boolean;
  recompute: boolean;
  error: unknown;
  computation: IComputationFunction<GValue>;
}

export const UNSET: any = Symbol('UNSET');
export const COMPUTING: any = Symbol('COMPUTING');
export const ERRORED: any = Symbol('ERRORED');

export const COMPUTED_SIGNAL_NODE: IComputedSignalNode<unknown> = {
  ...REACTIVE_NODE,
  equal: EQUAL_FUNCTION_STRICT_EQUAL,
  value: UNSET,
  error: undefined,
  outdated: true,
  recompute: false,
  computation: undefined as any,
};

export function computedUpdate<GValue>(node: IComputedSignalNode<GValue>): void {
  if (node.value === COMPUTING) {
    throw new Error('Detected cycle in computations.');
  } else {
    const oldValue = node.value;
    node.value = COMPUTING;

    let newValue: GValue;
    try {
      newValue = runSignalChangeContextOnce<GValue>('computed', node.computation, (): void =>
        computedChange<GValue>(node),
      );
    } catch (error: unknown) {
      newValue = ERRORED;
      node.error = error;
    }

    node.outdated = false;

    if (
      oldValue !== UNSET &&
      oldValue !== ERRORED &&
      newValue !== ERRORED &&
      node.equal(oldValue, newValue)
    ) {
      // same value => no changes
      node.value = oldValue;
    } else {
      node.value = newValue;

      if (oldValue !== UNSET) {
        reactiveNodeDispatchSignalChangeListeners(node);
      }
    }
  }
}

export function computedChange<GValue>(node: IComputedSignalNode<GValue>): void {
  node.outdated = true;

  if (node.recompute) {
    node.recompute = false;
    computedUpdate<GValue>(node);
  } else {
    reactiveNodeDispatchSignalChangeListeners(node);
  }
}

export function computedGet<GValue>(node: IComputedSignalNode<GValue>): GValue {
  // in an 'effect' context, the computed value must be refreshed to check if it changed or not.
  node.recompute ||= getCurrentSignalChangeContext() === 'effect';

  if (node.outdated) {
    computedUpdate<GValue>(node);
  }

  reactiveNodeAddSignalChangeListener(node);

  if (node.value === ERRORED) {
    throw node.error;
  }

  return node.value;
}
