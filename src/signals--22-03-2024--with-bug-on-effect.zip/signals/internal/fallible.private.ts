import { SIGNAL } from '../signal/signal.symbol';
import { IReadonlySignal } from '../signal/types/readonly-signal.type';
import { ISignalUpdateFunctionCallback } from '../signal/types/signal-update-function-callback.type';
import { ERRORED, UNSET } from './computed.private';
import {
  reactiveNodeAddSignalChangeListener,
  reactiveNodeDispatchSignalChangeListeners,
} from './reactive-node.private';
import { preventSignalWriteInSignalChangeContext } from './signal-change-context/signal-change-context.private';
import { ISignalNode, SIGNAL_NODE } from './signal.private';

export interface IFallibleNode<GValue> extends ISignalNode<GValue> {
  error: unknown;
}

export const FALLIBLE_NODE: IFallibleNode<unknown> = {
  ...SIGNAL_NODE,
  error: undefined,
};

export function fallibleGet<GValue>(node: IFallibleNode<GValue>): GValue {
  reactiveNodeAddSignalChangeListener(node);
  if (node.value === UNSET) {
    throw new Error('Unset.');
  } else if (node.value === ERRORED) {
    throw node.error;
  }
  return node.value;
}

export function fallibleSet<GValue>(
  node: IFallibleNode<GValue>,
  value: GValue,
  error?: unknown,
): void {
  preventSignalWriteInSignalChangeContext();

  if (
    node.value === UNSET ||
    node.value === ERRORED ||
    value === ERRORED ||
    !node.equal(value, node.value)
  ) {
    node.value = value;
    node.error = error;
    reactiveNodeDispatchSignalChangeListeners(node);
  }
}

export function fallibleThrow<GValue>(node: IFallibleNode<GValue>, error: unknown): void {
  fallibleSet<GValue>(node, ERRORED, error);
}

export function fallibleUpdate<GValue>(
  node: IFallibleNode<GValue>,
  updateFunction: ISignalUpdateFunctionCallback<GValue>,
): void {
  let value: GValue;
  let error: unknown;

  try {
    value = updateFunction(node.value);
  } catch (_error: unknown) {
    value = ERRORED;
    error = _error;
  }

  if (value === ERRORED) {
    fallibleThrow<GValue>(node, error);
  } else {
    fallibleSet<GValue>(node, value);
  }
}

export function fallibleAsReadonly<GValue>(node: IFallibleNode<GValue>): IReadonlySignal<GValue> {
  if (node.readonlySignal === undefined) {
    const readonlySignal: IReadonlySignal<GValue> = (): GValue => fallibleGet<GValue>(node);
    readonlySignal[SIGNAL] = node;
    node.readonlySignal = readonlySignal;
  }
  return node.readonlySignal;
}
