export type ISignalChangeContext = 'none' | 'effect' | 'computed';

export type ISignalChangeListener = () => void;
export type IOptionalSignalChangeListener = ISignalChangeListener | undefined;

let signalChangeContext: ISignalChangeContext = 'none';
let signalChangeListener: IOptionalSignalChangeListener = undefined;

export function getCurrentSignalChangeContext(): ISignalChangeContext {
  return signalChangeContext;
}

export function getCurrentSignalChangeListener(): IOptionalSignalChangeListener {
  return signalChangeListener;
}

export function preventSignalWriteInSignalChangeContext(): void {
  if (signalChangeContext !== 'none') {
    throw new Error('The signal cannot be written is this context.');
  }
}

// export function throwIfInContext(context: ISignalChangeContext, message?: string): void {
//   if (signalChangeContext === context) {
//     throw new Error(`${message ?? 'Operation not permitted'} is this context.`);
//   }
// }

// export function preventSignalCreationIfInSignalContext(): void {
//   if (isInSignalContext()) {
//     throw new Error('Cannot create a signal is this context.');
//   }
// }

export function runSignalChangeContextOnce<GReturn>(
  context: ISignalChangeContext,
  callback: () => GReturn,
  onChange: ISignalChangeListener,
): GReturn {
  let running: boolean = true;
  return runSignalChangeContext<GReturn>(context, callback, (): void => {
    if (running) {
      running = false;
      onChange();
    }
  });
}

export function runSignalChangeContext<GReturn>(
  context: ISignalChangeContext,
  callback: () => GReturn,
  onChange: IOptionalSignalChangeListener,
): GReturn {
  let _signalChangeContext: ISignalChangeContext = signalChangeContext;
  let _signalChangeListener: IOptionalSignalChangeListener = signalChangeListener;
  signalChangeContext = context;
  signalChangeListener = onChange;
  try {
    return callback();
  } finally {
    signalChangeContext = _signalChangeContext;
    signalChangeListener = _signalChangeListener;
  }
}

/**
 * Runs a context in which signals are not observed.
 */
export function runOutsideSignalChangeContext<GReturn>(callback: () => GReturn): GReturn {
  return runSignalChangeContext<GReturn>(
    'none' /* maybe keep same context ? */,
    callback,
    undefined,
  );
}
