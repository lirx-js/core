import { IObservable } from '../../../../../../../type/observable.type';
import { fromFetchBody } from '../body/from-fetch-body';
import { IFromFetchArrayBufferObservableNotifications } from './from-fetch-array-buffer-observable-notifications.type';

/**
 * Uses the Fetch API to make an HTTP request, and returns an ArrayBuffer
 */
export function fromFetchArrayBuffer(
  requestInfo: RequestInfo,
  requestInit?: RequestInit,
): IObservable<IFromFetchArrayBufferObservableNotifications> {
  return fromFetchBody<ArrayBuffer>(
    (response: Response) => response.arrayBuffer(),
    requestInfo,
    requestInit,
  );
}

