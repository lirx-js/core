import { IObservable } from '../../../../../../../type/observable.type';
import { fromFetchBody } from '../body/from-fetch-body';
import { IFromFetchJSONObservableNotifications } from './from-fetch-json-observable-notifications.type';
import { responseToJSON } from './pipe/response-to-json';

/**
 * Uses the Fetch API to make an HTTP request, and returns a JSON object
 */
export function fromFetchJSON<GData>(
  requestInfo: RequestInfo,
  requestInit?: RequestInit,
): IObservable<IFromFetchJSONObservableNotifications<GData>> {
  return fromFetchBody<GData>(
    responseToJSON,
    requestInfo,
    requestInit,
  );
}

