import {
  IFulfilledObservableOutNotifications,
} from '../../../../../../../../pipes/built-in/with-notifications/then/derived/fulfilled/fulfilled-observable-out-notifications.type';
import {
  fulfilledObservablePipe,
} from '../../../../../../../../pipes/built-in/with-notifications/then/derived/fulfilled/fulfilled-observable-pipe';
import { IThenObservableInNotifications } from '../../../../../../../../pipes/built-in/with-notifications/then/then-observable';
import { IObservablePipe } from '../../../../../../../../pipes/type/observable-pipe.type';
import { responseToBodyObservable } from '../../body/response-to-body-observable';
import { IFromFetchJSONObservableNotifications } from '../from-fetch-json-observable-notifications.type';
import { responseToJSON } from './response-to-json';

export function responseToJSONObservablePipe<GData>(): IObservablePipe<IThenObservableInNotifications<Response>, IFulfilledObservableOutNotifications<IFromFetchJSONObservableNotifications<GData>>> {
  return fulfilledObservablePipe(
    responseToBodyObservable<GData>(responseToJSON),
  );
}
