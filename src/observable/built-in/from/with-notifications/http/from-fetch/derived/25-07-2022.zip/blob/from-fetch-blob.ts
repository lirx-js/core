import { IObservable } from '../../../../../../../type/observable.type';
import { fromFetchBody } from '../body/from-fetch-body';
import { IFromFetchBlobObservableNotifications } from './from-fetch-blob-observable-notifications.type';
import { responseToBlob } from './response-to-blob';

/**
 * Uses the Fetch API to make an HTTP request, and returns a Blob
 */
export function fromFetchBlob(
  requestInfo: RequestInfo,
  requestInit?: RequestInit,
): IObservable<IFromFetchBlobObservableNotifications> {
  return fromFetchBody<Blob>(
    responseToBlob,
    requestInfo,
    requestInit,
  );
}

