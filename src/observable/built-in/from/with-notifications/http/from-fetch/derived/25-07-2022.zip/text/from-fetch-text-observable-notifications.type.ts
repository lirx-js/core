import { IFromFetchBodyObservableNotifications } from '../body/from-fetch-body-observable-notifications.type';

export type IFromFetchTextObservableNotifications = IFromFetchBodyObservableNotifications<string>;
