import { IFromFetchBodyObservableNotifications } from '../body/from-fetch-body-observable-notifications.type';

export type IFromFetchJSONObservableNotifications<GData> = IFromFetchBodyObservableNotifications<GData>;
