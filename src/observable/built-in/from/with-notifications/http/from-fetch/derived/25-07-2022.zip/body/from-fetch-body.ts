import { fulfilledObservable } from '../../../../../../../pipes/built-in/with-notifications/then/derived/fulfilled/fulfilled-observable';
import { IObservable } from '../../../../../../../type/observable.type';
import { fromFetch } from '../../from-fetch';
import { IFromFetchBodyObservableNotifications } from './from-fetch-body-observable-notifications.type';
import { IResponseToBodyMapFunction } from './response-to-body-map-function.type';
import { responseToBodyObservable } from './response-to-body-observable';

/**
 * Uses the Fetch API to make an HTTP request, and its body
 */
export function fromFetchBody<GData>(
  map: IResponseToBodyMapFunction<GData>,
  requestInfo: RequestInfo,
  requestInit?: RequestInit,
): IObservable<IFromFetchBodyObservableNotifications<GData>> {
  return fulfilledObservable(
    fromFetch(
      requestInfo,
      requestInit,
    ),
    responseToBodyObservable<GData>(map),
  );
}

