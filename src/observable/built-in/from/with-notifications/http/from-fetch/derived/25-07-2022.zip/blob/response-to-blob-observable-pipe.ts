import {
  IFulfilledObservableOutNotifications,
} from '../../../../../../../pipes/built-in/with-notifications/then/derived/fulfilled/fulfilled-observable-out-notifications.type';
import {
  fulfilledObservablePipe,
} from '../../../../../../../pipes/built-in/with-notifications/then/derived/fulfilled/fulfilled-observable-pipe';
import { IThenObservableInNotifications } from '../../../../../../../pipes/built-in/with-notifications/then/then-observable';
import { IObservablePipe } from '../../../../../../../pipes/type/observable-pipe.type';
import { responseToBodyObservable } from '../body/response-to-body-observable';
import { IFromFetchBlobObservableNotifications } from './from-fetch-blob-observable-notifications.type';
import { responseToBlob } from './response-to-blob';

export function responseToBlobObservablePipe(): IObservablePipe<IThenObservableInNotifications<Response>, IFulfilledObservableOutNotifications<IFromFetchBlobObservableNotifications>> {
  return fulfilledObservablePipe(
    responseToBodyObservable<Blob>(responseToBlob),
  );
}
