import { IObservable } from '../../../../../../../type/observable.type';
import { fromFetchBody } from '../body/from-fetch-body';
import { IFromFetchTextObservableNotifications } from './from-fetch-text-observable-notifications.type';

/**
 * Uses the Fetch API to make an HTTP request, and returns the result as text
 */
export function fromFetchText(
  requestInfo: RequestInfo,
  requestInit?: RequestInit,
): IObservable<IFromFetchTextObservableNotifications> {
  return fromFetchBody<string>(
    (response: Response) => response.text(),
    requestInfo,
    requestInit,
  );
}

