import {
  IFromReadableStreamObservableNotifications,
} from '../../../../readable-stream/w3c/from-readable-stream/from-readable-stream-observable-notifications.type';

export type IFromFetchStreamObservableNotifications = IFromReadableStreamObservableNotifications<Uint8Array>;
