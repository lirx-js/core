import {
  IFromPromiseFactoryObservableNotifications
} from '../../../../promise/from-promise-factory/from-promise-factory-observable-notifications.type';

export type IFromFetchBodyObservableNotifications<GData> = IFromPromiseFactoryObservableNotifications<GData>;
