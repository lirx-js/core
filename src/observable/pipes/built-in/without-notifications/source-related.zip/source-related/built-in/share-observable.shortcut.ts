export { shareObservable as share$$ } from './share-observable';


