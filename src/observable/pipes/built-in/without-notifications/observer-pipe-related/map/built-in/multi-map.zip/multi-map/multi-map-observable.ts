import { IObservable } from '../../../../../../../type/observable.type';
import { IMapFunction } from '../../../../../../../../observer/pipes/built-in/map/map-function.type';
import { mapObservable } from '../../map-observable';

export type IMultiMapResult<GMapFunctions extends readonly IMapFunction<any, any>[]> = {
  [GKey in keyof GMapFunctions]: GMapFunctions[GKey] extends IMapFunction<any, infer GOut>
    ? IObservable<GOut>
    : never;
};

/**
 * @experimental
 */
export function multiMapObservable<GIn, GMapFunctions extends readonly IMapFunction<GIn, any>[]>(
  subscribe: IObservable<GIn>,
  mapFunctions: GMapFunctions,
): IMultiMapResult<GMapFunctions> {
  return mapFunctions.map((mapFunction: IMapFunction<GIn, any>): IObservable<any> => {
    return mapObservable(subscribe, mapFunction);
  }) as IMultiMapResult<GMapFunctions>;
}


export function multiMapObservableSpread<GIn, GMapFunctions extends readonly IMapFunction<GIn, any>[]>(
  subscribe: IObservable<GIn>,
  ...mapFunctions: GMapFunctions
): IMultiMapResult<GMapFunctions> {
  return multiMapObservable<GIn, GMapFunctions>(subscribe, mapFunctions);
}


// export type IMultiMapResult<GMapFunctions extends readonly IMapFunction<any, any>[]> = {
//   [GKey in keyof GMapFunctions]: GMapFunctions[GKey] extends IMapFunction<any, infer GOut>
//     ? IObservable<GOut>
//     : never;
// };
//
// export function multiMap<GIn, GOut extends readonly any[]>(
//   subscribe: IObservable<GIn>,
//   mapFunction: IMapFunction<GIn, GOut>,
// ): IMultiMapResult<GMapFunctions> {
//   return mapFunctions.map((mapFunction: IMapFunction<GIn, any>): IObservable<any> => {
//     return mapObservable(subscribe, mapFunction);
//   }) as IMultiMapResult<GMapFunctions>;
// }
