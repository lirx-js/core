export { multiMapObservable as multiMap$$, multiMapObservableSpread as multiMapS$$ } from './multi-map-observable';


