import { EQUAL_FUNCTION_STRICT_EQUAL, IEqualFunction } from '@lirx/utils';
import { SignalError } from './signal-error.class';

/** --------------------------------------- PRODUCER --------------------------------------- **/

/* TYPES */

export interface IReactiveProducerUpdateValueFunction {
  (node: any): void;
}

export interface IReactiveProducer<GValue> {
  equal: IEqualFunction<GValue>;
  value: GValue | SignalError;
  updating: boolean;
  updateValue: IReactiveProducerUpdateValueFunction;
  consumers: IReactiveConsumer[];
}

export type IReactiveProducerWithValue<GValue> = [
  producer: IReactiveProducer<GValue>,
  value: GValue | SignalError,
];

/* INIT */

export const REACTIVE_PRODUCER: IReactiveProducer<unknown> = {
  equal: EQUAL_FUNCTION_STRICT_EQUAL,
  value: undefined,
  updating: false,
  updateValue: (): void => {},
  consumers: undefined as any,
};

export function initReactiveProducer<GValue>(
  producer: IReactiveProducer<GValue>,
  value: GValue | SignalError,
  equal: IEqualFunction<GValue> | undefined,
): void {
  if (equal) {
    producer.equal = equal;
  }

  producer.value = value;
  producer.consumers = [];
}

/* FUNCTIONS */

export function updateReactiveProducerValue(producer: IReactiveProducer<any>): void {
  if (producer.updating) {
    throw new Error('Detected cycle in updates.');
  } else {
    producer.updating = true;
    producer.updateValue(producer);
    producer.updating = false;
  }
}

export function getReactiveProducerValue<GValue>(producer: IReactiveProducer<GValue>): GValue {
  if (producer.value instanceof SignalError) {
    throw producer.value.error;
  }

  return producer.value;
}

export function updateAndGetReactiveProducerValue<GValue>(
  producer: IReactiveProducer<GValue>,
): GValue {
  updateReactiveProducerValue(producer);
  return getReactiveProducerValue<GValue>(producer);
}

/**
 * @public
 */
export function reactiveProducerGet<GValue>(producer: IReactiveProducer<GValue>): GValue {
  consumeReactiveProducer(producer);
  return updateAndGetReactiveProducerValue<GValue>(producer);
}

export function reactiveProducerSet<GValue>(
  producer: IReactiveProducer<GValue>,
  value: GValue | SignalError,
): void {
  preventSignalWriteInConsumerContext();
  setAndNotifyReactiveProducerValue<GValue>(producer, value);
}

export function setReactiveProducerValue<GValue>(
  producer: IReactiveProducer<GValue>,
  value: GValue | SignalError,
): boolean {
  if (
    producer.value instanceof SignalError ||
    value instanceof SignalError ||
    !producer.equal(value, producer.value)
  ) {
    producer.value = value;
    return true;
  } else {
    return false;
  }
}

export function setAndNotifyReactiveProducerValue<GValue>(
  producer: IReactiveProducer<GValue>,
  value: GValue | SignalError,
): void {
  if (setReactiveProducerValue(producer, value)) {
    markReactiveProducerConsumersAsOutdated(producer);
  }
}

export function markReactiveProducerConsumersAsOutdated(node: IReactiveProducer<any>): void {
  for (let i: number = 0; i < node.consumers.length; i++) {
    const consumer: IReactiveConsumer = node.consumers[i];
    if (!consumer.outdated) {
      consumer.outdated = true;
      consumer.onOutdated(consumer);
    }
  }
}

/** --------------------------------------- CONSUMER --------------------------------------- **/

/* TYPES */

export interface IReactiveConsumerOnOutdatedFunction {
  (node: any): void;
}

export interface IReactiveConsumer {
  producers: IReactiveProducerWithValue<unknown>[];
  outdated: boolean;
  onOutdated: IReactiveConsumerOnOutdatedFunction;
}

export type IOptionalReactiveConsumer = IReactiveConsumer | undefined;

/* INIT */

export const REACTIVE_CONSUMER: IReactiveConsumer = {
  producers: undefined as any,
  outdated: true,
  onOutdated: undefined as any,
};

export function initReactiveConsumer(consumer: IReactiveConsumer): void {
  consumer.producers = [];
}

export function isReactiveConsumerOutdated(consumer: IReactiveConsumer): boolean {
  if (consumer.outdated) {
    // TODO continue here
    for (let i: number = 0; i < consumer.producers.length; i++) {
      const [producer, value]: IReactiveProducerWithValue<unknown> = consumer.producers[i];
      if (!producer.equal(updateAndGetReactiveProducerValue(producer), value)) {
        return true;
      }
    }
  }
  return false;
}

/** SHARED **/

/* CURRENT */

let currentConsumer: IOptionalReactiveConsumer = undefined;

export function runInReactiveConsumerContext<GReturn>(
  consumer: IOptionalReactiveConsumer,
  callback: () => GReturn,
): GReturn {
  const previousObserver: IOptionalReactiveConsumer = currentConsumer;
  currentConsumer = consumer;
  try {
    return callback();
  } finally {
    currentConsumer = previousObserver;
  }
}

export function consumeReactiveProducer(producer: IReactiveProducer<any>): void {
  if (currentConsumer !== undefined) {
    bindReactiveConsumerWithReactiveProducer(currentConsumer, producer);
  }
}

export function preventSignalWriteInConsumerContext(): void {
  if (currentConsumer !== undefined) {
    throw new Error('The signal cannot be written is this context.');
  }
}

export function preventEffectCreationInConsumerContext(): void {
  if (currentConsumer !== undefined) {
    throw new Error('Cannot create an effect this context.');
  }
}

/* FUNCTIONS */

export function bindReactiveConsumerWithReactiveProducer(
  consumer: IReactiveConsumer,
  producer: IReactiveProducer<any>,
): void {
  producer.consumers.push(consumer);
  consumer.producers.push([producer, producer.value]);
}

// /** --------------------------------------- REACTIVE NODE --------------------------------------- **/
//
// /* TYPES */
//
// export interface IReactiveNodeComputationFunction<GValue> {
//   (): GValue;
// }
//
// export interface IReactiveNode<GValue> extends IReactiveConsumer, IReactiveProducer<GValue> {
//   computation: IReactiveNodeComputationFunction<GValue>;
// }
//
// /* INIT */
//
// export const REACTIVE_NODE: IReactiveNode<unknown> = {
//   ...REACTIVE_PRODUCER,
//   ...REACTIVE_CONSUMER,
//   updateValue: updateReactiveNode,
//   computation: undefined as any,
//   onOutdated: reactiveNodeOnOutdated,
// };
//
// export function initReactiveNode<GValue>(
//   node: IReactiveNode<GValue>,
//   computation: IReactiveNodeComputationFunction<GValue>,
//   equal: IEqualFunction<GValue> | undefined,
// ): void {
//   initReactiveConsumer(node);
//   initReactiveProducer<GValue>(node, SignalError.UNSET, equal);
//   node.computation = computation;
// }
//
// /* FUNCTIONS */
//
// export function reactiveNodeOnOutdated(node: IReactiveNode<any>): void {
//   markReactiveProducerConsumersAsOutdated(node);
// }
//
// export function runReactiveNodeComputation<GValue>(node: IReactiveNode<GValue>): void {
//   let newValue: GValue | SignalError;
//   try {
//     newValue = runInReactiveConsumerContext<GValue>(node, node.computation);
//   } catch (error: unknown) {
//     newValue = new SignalError(error);
//   }
//
//   node.outdated = false;
//   setAndNotifyReactiveProducerValue<GValue>(node, newValue);
// }
//
// export function updateReactiveNode(node: IReactiveNode<any>): void {
//   if (isReactiveConsumerOutdated(node)) {
//     runReactiveNodeComputation(node);
//   }
// }
