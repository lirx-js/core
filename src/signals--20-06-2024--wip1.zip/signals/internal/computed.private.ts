import { IEqualFunction } from '@lirx/utils';
import { IComputationFunction } from '../computed/types/computation-function.type';
import {
  initReactiveConsumer,
  initReactiveProducer,
  IReactiveConsumer,
  IReactiveProducer,
  isReactiveConsumerOutdated,
  markReactiveProducerConsumersAsOutdated,
  REACTIVE_CONSUMER,
  REACTIVE_PRODUCER,
  reactiveProducerGet,
  runInReactiveConsumerContext,
  setAndNotifyReactiveProducerValue,
} from './reactive-context.private';
import { SignalError } from './signal-error.class';

/* TYPES */

export interface IComputedContext<GValue> extends IReactiveConsumer, IReactiveProducer<GValue> {
  computation: IComputationFunction<GValue>;
}

/* INIT */

export const COMPUTED_CONTEXT: IComputedContext<unknown> = {
  ...REACTIVE_PRODUCER,
  ...REACTIVE_CONSUMER,
  updateValue: updateComputed,
  computation: undefined as any,
  onOutdated: computedOnOutdated,
};

export function initComputed<GValue>(
  context: IComputedContext<GValue>,
  computation: IComputationFunction<GValue>,
  equal: IEqualFunction<GValue> | undefined,
): void {
  initReactiveConsumer(context);
  initReactiveProducer<GValue>(context, SignalError.UNSET, equal);
  context.computation = computation;
}

/* FUNCTIONS */

export function computedGet<GValue>(context: IComputedContext<GValue>): GValue {
  return reactiveProducerGet<GValue>(context);
}

export function computedOnOutdated(context: IComputedContext<any>): void {
  markReactiveProducerConsumersAsOutdated(context);
}

export function runComputedComputation<GValue>(context: IComputedContext<GValue>): void {
  let newValue: GValue | SignalError;
  try {
    newValue = runInReactiveConsumerContext<GValue>(context, context.computation);
  } catch (error: unknown) {
    newValue = new SignalError(error);
  }

  context.outdated = false;
  setAndNotifyReactiveProducerValue<GValue>(context, newValue);
}

export function updateComputed(context: IComputedContext<any>): void {
  if (isReactiveConsumerOutdated(context)) {
    runComputedComputation(context);
  }
}
