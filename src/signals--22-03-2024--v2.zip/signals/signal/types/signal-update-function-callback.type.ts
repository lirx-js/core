export interface ISignalUpdateFunctionCallback<GValue> {
  (value: GValue): GValue;
}
