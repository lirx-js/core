import { IUnsubscribe } from '@lirx/unsubscribe';

export type IUnsubscribeOfEffect = IUnsubscribe;
