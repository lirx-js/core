import {
  EFFECT_CONTEXT,
  effectContextRun,
  effectContextStop,
  IEffectContext,
} from '../internal/effect.private';
import { getCurrentReactiveContext } from '../internal/reactive-context.private';
import { IEffetFunction } from './types/effet-function.type';
import { IUnsubscribeOfEffect } from './types/unsubscribe-of-effect.type';

export function effect(effectFunction: IEffetFunction): IUnsubscribeOfEffect {
  if (getCurrentReactiveContext() !== undefined) {
    throw new Error('Cannot create an effect in this context.');
  }

  const context: IEffectContext = Object.create(EFFECT_CONTEXT);
  context.effectFunction = effectFunction;

  effectContextRun(context);

  return (): void => {
    effectContextStop(context);
  };
}
