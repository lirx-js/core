import { ICreateSignalOptions } from '../../signal/types/create-signal-options.type';

export interface ICreateFallibleOptions<GValue> extends ICreateSignalOptions<GValue> {}
