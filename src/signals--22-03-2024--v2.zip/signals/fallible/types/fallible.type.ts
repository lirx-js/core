import { ISignal } from '../../signal/types/signal.type';

export interface IFallible<GValue> extends ISignal<GValue> {
  throw(error: unknown): void;
}
