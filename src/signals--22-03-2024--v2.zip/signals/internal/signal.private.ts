import { EQUAL_FUNCTION_STRICT_EQUAL, IEqualFunction } from '@lirx/utils';
import { SIGNAL } from '../signal/signal.symbol';
import { IReadonlySignal } from '../signal/types/readonly-signal.type';
import { ISignalUpdateFunctionCallback } from '../signal/types/signal-update-function-callback.type';
import {
  IReactiveContextChangesSignaler,
  REACTIVE_CONTEXT_CHANGES_SIGNALER,
  markReactiveContextChangesSignalerAsChanged,
  markReactiveContextChangesSignalerAsObserved,
  preventSignalWriteInSignalContext,
} from './reactive-context.private';

/* NODE */

export interface ISignalNode<GValue> extends IReactiveContextChangesSignaler {
  equal: IEqualFunction<GValue>;
  value: GValue;
  readonlySignal: IReadonlySignal<GValue> | undefined;
}

export const SIGNAL_NODE: ISignalNode<unknown> = {
  ...REACTIVE_CONTEXT_CHANGES_SIGNALER,
  equal: EQUAL_FUNCTION_STRICT_EQUAL,
  value: undefined,
  readonlySignal: undefined,
};

/* GET */

export type ISignalGetNode<GValue> = Pick<ISignalNode<GValue>, 'value'> &
  IReactiveContextChangesSignaler;

export function signalGet<GValue>(node: ISignalGetNode<GValue>): GValue {
  markReactiveContextChangesSignalerAsObserved(node);
  return node.value;
}

/* SET */

export type ISignalSetNode<GValue> = Pick<ISignalNode<GValue>, 'value' | 'equal'> &
  IReactiveContextChangesSignaler;

export function signalSet<GValue>(node: ISignalSetNode<GValue>, value: GValue): void {
  preventSignalWriteInSignalContext();
  signalSetNoCheck<GValue>(node, value);
}

export function signalSetNoCheck<GValue>(node: ISignalSetNode<GValue>, value: GValue): void {
  if (!node.equal(value, node.value)) {
    node.value = value;
    markReactiveContextChangesSignalerAsChanged(node);
  }
}

export type ISignalUpdateNode<GValue> = ISignalSetNode<GValue>;

export function signalUpdate<GValue>(
  node: ISignalUpdateNode<GValue>,
  updateFunction: ISignalUpdateFunctionCallback<GValue>,
): void {
  signalSet<GValue>(node, updateFunction(node.value));
}

/* AS READONLY */

export type ISignalAsReadonlyNode<GValue> = Pick<ISignalNode<GValue>, 'readonlySignal'> &
  ISignalGetNode<GValue>;

export function signalAsReadonly<GValue>(
  node: ISignalAsReadonlyNode<GValue>,
): IReadonlySignal<GValue> {
  if (node.readonlySignal === undefined) {
    const readonlySignal: IReadonlySignal<GValue> = (): GValue => signalGet<GValue>(node);
    readonlySignal[SIGNAL] = node;
    node.readonlySignal = readonlySignal;
  }
  return node.readonlySignal;
}
