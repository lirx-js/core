/** REACTIVE CONTEXT **/

/* TYPES */

export interface IReactiveContext<
  GType extends string,
  GSelf extends IReactiveContext<GType, GSelf>,
> {
  type: GType;
  changeVersion: number;
  onChange: (context: GSelf) => void;
}

export type IGenericReactiveContext = IReactiveContext<any, any>;
export type IOptionalGenericReactiveContext = IGenericReactiveContext | undefined;

export function createReactiveContext<
  GType extends string,
  GSelf extends IReactiveContext<GType, GSelf>,
>(type: GType, onChange: (context: GSelf) => void): IReactiveContext<GType, GSelf> {
  return {
    type,
    changeVersion: 0,
    onChange,
  };
}

/* CURRENT */

let currentReactiveContext: IOptionalGenericReactiveContext = undefined;

export function getCurrentReactiveContext(): IOptionalGenericReactiveContext {
  return currentReactiveContext;
}

export function preventSignalWriteInSignalContext(): void {
  if (currentReactiveContext !== undefined) {
    throw new Error('The signal cannot be written is this context.');
  }
}

/* FUNCTIONS */

export function runReactiveContext<GReturn>(
  context: IGenericReactiveContext,
  callback: () => GReturn,
): GReturn {
  const previousReactiveContext: IOptionalGenericReactiveContext = currentReactiveContext;
  currentReactiveContext = context;
  try {
    return callback();
  } finally {
    currentReactiveContext = previousReactiveContext;
  }
}

/** REACTIVE CONTEXT SIGNALER **/

/* TYPES */

export interface IReactiveContextChangesSignaler {
  contexts: IGenericReactiveContext[];
}

export const REACTIVE_CONTEXT_CHANGES_SIGNALER: IReactiveContextChangesSignaler = {
  contexts: undefined as any,
};

/* FUNCTIONS */

export function initReactiveContextChangesSignaler(
  signaler: IReactiveContextChangesSignaler,
): void {
  signaler.contexts = [];
}

export function markReactiveContextChangesSignalerAsObserved(
  signaler: IReactiveContextChangesSignaler,
): void {
  const currentReactiveContext: IOptionalGenericReactiveContext = getCurrentReactiveContext();
  if (currentReactiveContext !== undefined) {
    signaler.contexts.push(currentReactiveContext);
  }
}

let changeVersion: number = 0;

export function markReactiveContextChangesSignalerAsChanged(
  signaler: IReactiveContextChangesSignaler,
): void {
  let index: number = signaler.contexts.length;
  if (index > 0) {
    changeVersion = (changeVersion + 1) % 0x100000000;
    const currentChangeVersion: number = changeVersion;
    const contexts: readonly IGenericReactiveContext[] = signaler.contexts;
    signaler.contexts = [];
    while (--index >= 0) {
      const context: IGenericReactiveContext = contexts[index];
      if (context.changeVersion !== currentChangeVersion) {
        context.changeVersion = currentChangeVersion;
        context.onChange(context);
      }
    }
  }
}
