import { EQUAL_FUNCTION_STRICT_EQUAL, IEqualFunction } from '@lirx/utils';
import { IComputationFunction } from '../computed/types/computation-function.type';
import {
  IGenericReactiveContext,
  IOptionalGenericReactiveContext,
  IReactiveContext,
  IReactiveContextChangesSignaler,
  REACTIVE_CONTEXT_CHANGES_SIGNALER,
  createReactiveContext,
  getCurrentReactiveContext,
  markReactiveContextChangesSignalerAsChanged,
  runReactiveContext,
} from './reactive-context.private';

export interface IComputedNode<GValue>
  extends IReactiveContext<'computed', IComputedNode<GValue>>,
    IReactiveContextChangesSignaler {
  equal: IEqualFunction<GValue>;
  value: GValue;
  outdated: boolean;
  recompute: boolean;
  error: unknown;
  computation: IComputationFunction<GValue>;
}

export const UNSET: any = Symbol('UNSET');
export const COMPUTING: any = Symbol('COMPUTING');
export const ERRORED: any = Symbol('ERRORED');

export const COMPUTED_NODE: IComputedNode<unknown> = {
  ...createReactiveContext('computed', computedContextChanged),
  ...REACTIVE_CONTEXT_CHANGES_SIGNALER,
  equal: EQUAL_FUNCTION_STRICT_EQUAL,
  value: UNSET,
  error: undefined,
  outdated: true,
  recompute: false,
  computation: undefined as any,
};

export function isComputedNode<GValue>(
  input: IGenericReactiveContext,
): input is IComputedNode<GValue> {
  return input.type === 'computed';
}

export function computedContextChanged<GValue>(node: IComputedNode<GValue>): void {
  node.outdated = true;

  if (node.recompute) {
    node.recompute = false;
    if (computedUpdate<GValue>(node)) {
      markReactiveContextChangesSignalerAsChanged(node);
    }
  }
}

export function computedUpdate<GValue>(node: IComputedNode<GValue>): boolean {
  if (node.value === COMPUTING) {
    throw new Error('Detected cycle in computations.');
  } else {
    const oldValue = node.value;
    node.value = COMPUTING;

    let newValue: GValue;
    try {
      newValue = runReactiveContext<GValue>(node, node.computation);
    } catch (error: unknown) {
      newValue = ERRORED;
      node.error = error;
    }

    node.outdated = false;

    if (
      oldValue !== UNSET &&
      oldValue !== ERRORED &&
      newValue !== ERRORED &&
      node.equal(oldValue, newValue)
    ) {
      // same value => no changes
      node.value = oldValue;
      return false;
    } else {
      node.value = newValue;
      return oldValue !== UNSET;
    }
  }
}

export function computedGet<GValue>(node: IComputedNode<GValue>): GValue {
  // markReactiveContextChangesSignalerAsObserved(node);
  const currentReactiveContext: IOptionalGenericReactiveContext = getCurrentReactiveContext();
  if (currentReactiveContext !== undefined) {
    node.contexts.push(currentReactiveContext);
    node.recompute = true;
  }

  if (node.outdated) {
    computedUpdate<GValue>(node);
  }

  if (node.value === ERRORED) {
    throw node.error;
  }

  return node.value;
}
