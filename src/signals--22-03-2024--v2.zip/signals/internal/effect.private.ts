import { createMulticastSource } from '../../observer-observable-pair/build-in/source/built-in/multicast-source/create-multicast-source';
import { IMulticastSource } from '../../observer-observable-pair/build-in/source/built-in/multicast-source/multicast-source.type';
import { IEffetFunction } from '../effect/types/effet-function.type';
import {
  createReactiveContext,
  IGenericReactiveContext,
  IReactiveContext,
  runReactiveContext,
} from './reactive-context.private';

/* CONTEXT */

export interface IEffectContext extends IReactiveContext<'effect', IEffectContext> {
  running: boolean;
  effectFunction: IEffetFunction;
  cleanUpSource: IMulticastSource<void>;
}

export const EFFECT_CONTEXT: IEffectContext = {
  ...createReactiveContext('effect', effectContextChanged),
  effectFunction: undefined as any,
  running: true,
  cleanUpSource: undefined as any,
};

export function isEffectContext(input: IGenericReactiveContext): input is IEffectContext {
  return input.type === 'effect';
}

export function effectContextChanged(context: IEffectContext): void {
  if (context.running) {
    context.cleanUpSource.emit();
  }
  queueMicrotask((): void => {
    if (context.running) {
      effectContextRun(context);
    }
  });
}

export function effectContextRun(context: IEffectContext): void {
  runReactiveContext(context, (): void => {
    context.cleanUpSource = createMulticastSource<void>();
    context.effectFunction(context.cleanUpSource.subscribe);
  });
}

export function effectContextStop(context: IEffectContext): void {
  if (context.running) {
    context.running = false;
    context.cleanUpSource.emit();
  }
}
