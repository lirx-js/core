import { getGlobalThis } from '@lirx/utils';

/**
 * @deprecated
 */
export function isAbortControllerSupported(): boolean {
  return ('AbortController' in getGlobalThis());
}
