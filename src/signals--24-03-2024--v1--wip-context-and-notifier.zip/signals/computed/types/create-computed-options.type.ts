import { ICreateSignalOptions } from '../../signal/types/create-signal-options.type';

export interface ICreateComputedOptions<GValue> extends ICreateSignalOptions<GValue> {}
