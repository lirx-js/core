/** REACTIVE NOTIFIER **/

/* TYPES */

export interface IReactiveNotifier {
  contexts: IReactiveContext[];
}

export const REACTIVE_NOTIFIER: IReactiveNotifier = {
  contexts: undefined as any,
};

/* FUNCTIONS */

export function initReactiveNotifier(notifier: IReactiveNotifier): void {
  notifier.contexts = [];
}

export function markReactiveNotifierAsObserved(notifier: IReactiveNotifier): void {
  if (currentReactiveContext !== undefined) {
    addReactiveNotifierToReactiveContext(currentReactiveContext, notifier);
  }
}

export function markReactiveNotifierAsDirty(notifier: IReactiveNotifier): void {
  notifier.contexts.forEach((context: IReactiveContext): void => {
    markReactiveContextAsDirty(context, notifier);
  });
}

export function markReactiveNotifierAsOutdated(notifier: IReactiveNotifier): void {
  notifier.contexts.forEach((context: IReactiveContext): void => {
    markReactiveContextAsOutdated(context);
  });
}

/** REACTIVE CONTEXT **/

/* TYPES */

const REACTIVE_CONTEXT_STATE_FRESH = 0;
const REACTIVE_CONTEXT_STATE_DIRTY = 1;
const REACTIVE_CONTEXT_STATE_OUTDATED = 2;

type IReactiveContextState =
  | typeof REACTIVE_CONTEXT_STATE_FRESH
  | typeof REACTIVE_CONTEXT_STATE_DIRTY
  | typeof REACTIVE_CONTEXT_STATE_OUTDATED;

export interface IReactiveContext extends IReactiveNotifier {
  state: IReactiveContextState;
  notifiers: Set<IReactiveNotifier>;
  dirtyNotifiers: IReactiveNotifier[];
}

type IOptionalReactiveContext = IReactiveContext | undefined;

export const REACTIVE_CONTEXT: IReactiveContext = {
  ...REACTIVE_NOTIFIER,
  state: REACTIVE_CONTEXT_STATE_OUTDATED,
  notifiers: undefined as any,
  dirtyNotifiers: undefined as any,
};

/* CURRENT */

let currentReactiveContext: IOptionalReactiveContext = undefined;

// export function getCurrentReactiveContext(): IOptionalReactiveContext {
//   return currentReactiveContext;
// }

/* FUNCTIONS */

export function initReactiveContext(context: IReactiveContext): void {
  initReactiveNotifier(context);
  context.notifiers = new Set<IReactiveNotifier>();
  context.dirtyNotifiers = [];
}

export function addReactiveNotifierToReactiveContext(
  context: IReactiveContext,
  notifier: IReactiveNotifier,
): void {
  if (!context.notifiers.has(notifier)) {
    context.notifiers.add(notifier);
    notifier.contexts.push(context);
  }
}

export function markReactiveContextAsDirty(
  context: IReactiveContext,
  dirtyNotifier: IReactiveNotifier,
): void {
  // console.assert(context.state !== REACTIVE_CONTEXT_STATE_OUTDATED);
  const markParentContextsAsDirty: boolean = context.state === REACTIVE_CONTEXT_STATE_FRESH;

  context.dirtyNotifiers.push(dirtyNotifier);
  context.state = REACTIVE_CONTEXT_STATE_DIRTY;

  if (markParentContextsAsDirty) {
    markReactiveNotifierAsDirty(context);
  }
}

export function markReactiveContextAsOutdated(context: IReactiveContext): void {
  // console.assert(context.state !== REACTIVE_CONTEXT_STATE_OUTDATED);
  const markParentContextsAsDirty: boolean = context.state === REACTIVE_CONTEXT_STATE_FRESH;

  context.dirtyNotifiers = [];
  context.state = REACTIVE_CONTEXT_STATE_OUTDATED;
}

export function runReactiveContext<GReturn>(
  context: IReactiveContext,
  callback: () => GReturn,
): GReturn {
  // TODO ensure no notifiers and outdated
  const previousReactiveContext: IOptionalReactiveContext = currentReactiveContext;
  currentReactiveContext = context;
  try {
    return callback();
  } finally {
    currentReactiveContext = previousReactiveContext;
  }
}

export function preventSignalWriteInSignalContext(): void {
  if (currentReactiveContext !== undefined) {
    throw new Error('The signal cannot be written is this context.');
  }
}

/*---------*/

// /** REACTIVE NODE OBSERVER **/
//
// /* TYPES */
//
// // export type IReactiveNodeChangeType = '';
//
// export interface IReactiveNodeObserver {
//   (): void;
// }
//
// export type IOptionalReactiveNodeObserver = IReactiveNodeObserver | undefined;
//
// /* CURRENT */
//
// let currentReactiveNodeObserver: IOptionalReactiveNodeObserver = undefined;
//
// export function getCurrentReactiveNodeObserver(): IOptionalReactiveNodeObserver {
//   return currentReactiveNodeObserver;
// }
//
// export function preventSignalWriteInSignalContext(): void {
//   if (currentReactiveNodeObserver !== undefined) {
//     throw new Error('The signal cannot be written is this context.');
//   }
// }
//
// /* FUNCTIONS */
//
// export function runReactiveContext<GReturn>(
//   callback: () => GReturn,
//   reactiveNodeObserver: IOptionalReactiveNodeObserver,
// ): GReturn {
//   const previousReactiveNodeObserver: IOptionalReactiveNodeObserver = currentReactiveNodeObserver;
//   currentReactiveNodeObserver = reactiveNodeObserver;
//   try {
//     return callback();
//   } finally {
//     currentReactiveNodeObserver = previousReactiveNodeObserver;
//   }
// }
//
// /** REACTIVE CONTEXT SIGNALER **/
//
// /* TYPES */
//
// export interface IReactiveNode {
//   observers: IReactiveNodeObserver[];
// }
//
// export const REACTIVE_NODE: IReactiveNode = {
//   observers: undefined as any,
// };
//
// /* FUNCTIONS */
//
// export function initReactiveNode(node: IReactiveNode): void {
//   node.observers = [];
// }
//
// export function markReactiveNodeAsObserved(node: IReactiveNode): void {
//   if (currentReactiveNodeObserver !== undefined) {
//     node.observers.push(currentReactiveNodeObserver);
//   }
// }
//
// export function markReactiveContextChangesSignalerAsChanged(node: IReactiveNode): void {
//   let index: number = node.observers.length;
//   if (index > 0) {
//     const observers: readonly IReactiveNodeObserver[] = node.observers;
//     node.observers = [];
//     while (--index >= 0) {
//       observers[index]();
//     }
//   }
// }
