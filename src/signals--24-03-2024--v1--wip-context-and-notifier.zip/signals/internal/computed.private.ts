import { EQUAL_FUNCTION_STRICT_EQUAL, IEqualFunction } from '@lirx/utils';
import { IComputationFunction } from '../computed/types/computation-function.type';
import {
  IOptionalReactiveNodeObserver,
  IReactiveNode,
  REACTIVE_NODE,
  getCurrentReactiveNodeObserver,
  markReactiveContextChangesSignalerAsChanged,
  runReactiveContext,
} from './reactive-context.private';

export interface IComputedNode<GValue> extends IReactiveNode {
  equal: IEqualFunction<GValue>;
  value: GValue;
  valueChanged: boolean;
  outdated: boolean;
  recompute: boolean;
  error: unknown;
  computation: IComputationFunction<GValue>;
}

export const UNSET: any = Symbol('UNSET');
export const COMPUTING: any = Symbol('COMPUTING');
export const ERRORED: any = Symbol('ERRORED');

export const COMPUTED_NODE: IComputedNode<unknown> = {
  ...REACTIVE_NODE,
  equal: EQUAL_FUNCTION_STRICT_EQUAL,
  value: UNSET,
  valueChanged: false,
  error: undefined,
  outdated: true,
  recompute: false,
  computation: undefined as any,
};

export function computedContextChanged<GValue>(node: IComputedNode<GValue>): void {
  node.outdated = true;
  // markReactiveContextChangesSignalerAsChanged(node);

  if (node.recompute) {
    node.recompute = false;
    node.valueChanged = false;
    queueMicrotask((): void => {
      computedUpdate<GValue>(node);
      if (node.valueChanged) {
        markReactiveContextChangesSignalerAsChanged(node);
      }
    });
  }
}

export function computedUpdate<GValue>(node: IComputedNode<GValue>): void {
  if (node.outdated) {
    if (node.value === COMPUTING) {
      throw new Error('Detected cycle in computations.');
    } else {
      const oldValue = node.value;
      node.value = COMPUTING;

      let newValue: GValue;
      try {
        newValue = runReactiveContext<GValue>(node.computation, (): void => {
          computedContextChanged<GValue>(node);
        });
      } catch (error: unknown) {
        newValue = ERRORED;
        node.error = error;
      }

      node.outdated = false;

      if (
        oldValue !== UNSET &&
        oldValue !== ERRORED &&
        newValue !== ERRORED &&
        node.equal(oldValue, newValue)
      ) {
        // same value => no changes
        node.value = oldValue;
      } else {
        node.value = newValue;
        // if (oldValue !== UNSET)
        node.valueChanged = true;
      }
    }
  }
}

export function computedGet<GValue>(node: IComputedNode<GValue>): GValue {
  // markReactiveContextChangesSignalerAsObserved(node);
  const currentReactiveNodeObserver: IOptionalReactiveNodeObserver =
    getCurrentReactiveNodeObserver();
  if (currentReactiveNodeObserver !== undefined) {
    node.observers.push(currentReactiveNodeObserver);
    node.recompute = true;
  }

  computedUpdate<GValue>(node);

  if (node.value === ERRORED) {
    throw node.error;
  }

  return node.value;
}
