import { createMulticastSource } from '../../observer-observable-pair/build-in/source/built-in/multicast-source/create-multicast-source';
import { IMulticastSource } from '../../observer-observable-pair/build-in/source/built-in/multicast-source/multicast-source.type';
import { IEffetFunction } from '../effect/types/effet-function.type';
import { runReactiveContext } from './reactive-context.private';

/* CONTEXT */

export interface IEffectContext {
  effectFunction: IEffetFunction;
  running: boolean;
  awaitingChanges: boolean;
  cleanUpSource: IMulticastSource<void>;
}

export const EFFECT_CONTEXT: IEffectContext = {
  effectFunction: undefined as any,
  running: true,
  awaitingChanges: true,
  cleanUpSource: undefined as any,
};

export function effectContextChanged(context: IEffectContext): void {
  if (context.running && context.awaitingChanges) {
    context.awaitingChanges = false;
    context.cleanUpSource.emit();

    queueMicrotask((): void => {
      effectContextRunInContext(context);
    });
  }
}

export function effectContextRunInContext(context: IEffectContext): void {
  if (context.running) {
    runReactiveContext(
      (): void => {
        effectContextRun(context);
      },
      (): void => {
        effectContextChanged(context);
      },
    );
  }
}

export function effectContextRun(context: IEffectContext): void {
  context.awaitingChanges = true;
  context.cleanUpSource = createMulticastSource<void>();
  context.effectFunction(context.cleanUpSource.subscribe);
}

export function effectContextStop(context: IEffectContext): void {
  if (context.running) {
    context.running = false;
    context.cleanUpSource.emit();
  }
}
