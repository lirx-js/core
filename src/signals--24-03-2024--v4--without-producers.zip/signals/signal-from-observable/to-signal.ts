import { IDefaultInNotificationsUnion } from '../../misc/notifications/default-notifications-union.type';
import { IObservable } from '../../observable/type/observable.type';
import { initReactiveProducer } from '../internal/reactive-context.private';

import { SignalError } from '../internal/signal-error.class';
import {
  ISignalFromObservableNode,
  SIGNAL_FROM_OBSERVABLE_NODE,
  signalFromObservableActivateOrDeactivateForNotification,
  signalFromObservableActivateOrDeactivateForRawValue,
  signalFromObservableGet,
  signalFromObservableIsActive,
} from '../internal/signal-from-observable.private';
import { SIGNAL } from '../signal/signal.symbol';
import {
  ICreateSignalFromNotificationsObservableOptions,
  ICreateSignalFromObservableOptions,
  ICreateSignalFromValueObservableOptions,
} from './types/create-signal-from-observable-options.type';
import { ISignalFromObservable } from './types/signal-from-observable.type';

export function toSignal<GValue>(
  value$: IObservable<GValue>,
  options?: ICreateSignalFromValueObservableOptions<GValue>,
): ISignalFromObservable<GValue>;
export function toSignal<GValue>(
  value$: IObservable<IDefaultInNotificationsUnion<GValue>>,
  options: ICreateSignalFromNotificationsObservableOptions<GValue>,
): ISignalFromObservable<GValue>;
export function toSignal<GValue>(
  value$: IObservable<GValue> | IObservable<IDefaultInNotificationsUnion<GValue>>,
  options?:
    | ICreateSignalFromObservableOptions<GValue>
    | ICreateSignalFromNotificationsObservableOptions<GValue>,
): ISignalFromObservable<GValue> {
  // preventCreationIfInSignalContext();

  const node: ISignalFromObservableNode<GValue> = Object.create(SIGNAL_FROM_OBSERVABLE_NODE);
  initReactiveProducer(
    node,
    options && 'initialValue' in options ? options.initialValue! : SignalError.UNSET,
    options?.equal,
  );
  node.value$ = value$;

  const signal: ISignalFromObservable<GValue> = ((): GValue =>
    signalFromObservableGet(node)) as ISignalFromObservable<GValue>;
  signal[SIGNAL] = node;

  signal.isActive = (): boolean => signalFromObservableIsActive(node);
  signal.activate =
    options?.mode === 'notification'
      ? (activate?: boolean): void =>
          signalFromObservableActivateOrDeactivateForNotification(node, activate)
      : (activate?: boolean): void =>
          signalFromObservableActivateOrDeactivateForRawValue(node, activate);

  signal.activate(true);

  return signal;
}
