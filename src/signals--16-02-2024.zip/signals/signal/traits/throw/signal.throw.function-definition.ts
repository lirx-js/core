export interface ISignalThrowFunction {
  (
    error: any,
  ): void;
}
