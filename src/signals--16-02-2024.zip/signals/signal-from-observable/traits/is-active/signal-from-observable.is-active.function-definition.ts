export interface ISignalFromObservableIsActiveFunction {
  (): boolean;
}
