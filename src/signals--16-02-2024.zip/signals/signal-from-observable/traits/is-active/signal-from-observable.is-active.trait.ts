import { ISignalFromObservableIsActiveFunction } from './signal-from-observable.is-active.function-definition';

export interface ISignalFromObservableIsActiveTrait {
  isActive: ISignalFromObservableIsActiveFunction;
}
