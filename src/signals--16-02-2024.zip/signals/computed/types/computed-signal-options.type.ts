import { ISignalOptions } from '../../signal/types/signal-options.type';

export interface IComputedSignalOptions<GValue> extends ISignalOptions<GValue> {
}
