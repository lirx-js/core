import { Writable } from '@lirx/utils';

export interface IWritableSignalMutateFunction<GValue> {
  (
    value: Writable<GValue>,
  ): void;
}
