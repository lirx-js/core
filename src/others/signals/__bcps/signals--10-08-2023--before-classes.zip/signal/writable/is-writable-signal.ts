import { isFunction } from '@lirx/utils';
import { IWritableSignal } from './writable-signal.type';
import { isSignal } from '../is-signal';

export function isWritableSignal<GValue>(
  input: unknown,
): input is IWritableSignal<GValue> {
  return isSignal(input)
    && isFunction((input as any).set);
}
