export const SIGNAL = Symbol('signal');
