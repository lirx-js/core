import { IAsymmetricSignal } from './asymmetric-signal.type';
import { ISignalOptions } from '../signal-options.type';
import { IMapFunction } from '../../../../observer/pipes/built-in/map/map-function.type';
import { signal } from '../signal';

export function asymmetricSignal<GSetValue, GValue extends GSetValue>(
  initialValue: GValue,
  map: IMapFunction<GSetValue, GValue>,
  options?: ISignalOptions<GValue>,
): IAsymmetricSignal<GSetValue, GValue> {
  const _signal = signal<GValue>(
    initialValue,
    options,
  );

  const _set = _signal.set;
  _signal.set = (
    value: GSetValue,
    force?: boolean,
  ): void => {
    return _set(map(value), force);
  };

  return _signal;
}
