import { IWritableSignal } from '../writable/writable-signal.type';

export interface IAsymmetricSignal<GSetValue, GValue extends GSetValue> extends IWritableSignal<GValue> {
  set(
    value: GSetValue,
    force?: boolean, // (default: false)
  ): void;
}
