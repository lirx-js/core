import { ISignalOptions } from '../signal/signal-options.type';
import { Signal } from './signal.class';
import { IMapFunction } from '../../../observer/pipes/built-in/map/map-function.type';

/* INTERNAL SIGNAL CLASS */

export class AsymmetricSignal<GSetValue, GValue extends GSetValue> extends Signal<GValue> {
  readonly #map: IMapFunction<GSetValue, GValue>;

  constructor(
    initialValue: GValue,
    map: IMapFunction<GSetValue, GValue>,
    options?: ISignalOptions<GValue>,
  ) {
    super(initialValue, options);
    this.#map = map;
  }

  override set(
    value: GSetValue,
    force?: boolean,
  ): void {
    super.set(this.#map(value), force);
  }
}

export type IGenericAsymmetricSignalClass = AsymmetricSignal<any, any>;

