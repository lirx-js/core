export type ISignalWriteMode =
  | 'allow'
  | 'forbid'
  | 'queue'
