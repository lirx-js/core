export interface IEffectOptions {
}
