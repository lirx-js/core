import { IObservable } from '../../../observable/type/observable.type';
import { IWritableSignal } from '../signal/writable/writable-signal.type';

export type IOnCleanUpFunction = IObservable<void>;

export type ISetSignalMode =
  | 'after'
  | 'debounce'
  ;

export interface IEffetSetFunctionOptions {
  mode?: ISetSignalMode;
  force?: boolean;
}

export interface IEffetSetFunction {
  <GValue>(
    signal: IWritableSignal<GValue>,
    value: GValue,
    options?: IEffetSetFunctionOptions,
  ): void;
}

export interface IEffectFunctionOptions {
  onCleanUp: IOnCleanUpFunction;
  set: IEffetSetFunction;
}

export interface IEffetFunction {
  (
    options: IEffectFunctionOptions,
  ): void;
}
