import { IUnsubscribe } from '@lirx/utils';
import {
  debounceMicrotaskObservable,
} from '../../../observable/pipes/built-in/without-notifications/time-related/debounce-microtask/debounce-microtask-observable';
import { IObservable, IUnsubscribeOfObservable } from '../../../observable/type/observable.type';
import { createMulticastSource } from '../../../observer-observable-pair/build-in/source/built-in/multicast-source/create-multicast-source';
import { IMulticastSource } from '../../../observer-observable-pair/build-in/source/built-in/multicast-source/multicast-source.type';
import { runAllowSignalWritesContext } from '../internal/allow-signal-writes';
import { runSignalContextAndObserveChanges } from '../internal/run-signal-context';
import { IGenericWritableSignal, IWritableSignal } from '../signal/writable/writable-signal.type';
import { IEffectOptions } from './effect-options.type';
import { IEffetFunction, IEffetSetFunctionOptions } from './effet-function.type';

type IFutureSet = [
  signal: IGenericWritableSignal,
  value: any,
];

export function effect(
  effectFunction: IEffetFunction,
  {}: IEffectOptions = {},
): IUnsubscribe {
  let unsubscribeOfSignals: IUnsubscribeOfObservable;
  let cleanUpSource: IMulticastSource<void>;

  const update = (): void => {
    if (cleanUpSource !== void 0) {
      cleanUpSource.emit();
    }
    cleanUpSource = createMulticastSource<void>();

    const futureSetAfter: IFutureSet[] = [];

    const set = <GValue>(
      signal: IWritableSignal<GValue>,
      value: GValue,
      {
        mode = 'debounce',
      }: IEffetSetFunctionOptions = {},
    ): void => {
      if (mode === 'after') {
        futureSetAfter.push([
          signal,
          value,
        ]);
      } else {
        queueMicrotask((): void => {
          signal.set(value);
        });
      }
    };

    const signalsChange$: IObservable<unknown> = runSignalContextAndObserveChanges(
      (): void => {
        runAllowSignalWritesContext((): void => {
          effectFunction({
            onCleanUp: cleanUpSource.subscribe,
            set,
          });
        }, false);
      },
      {
        throwIfChildSignalContext: true,
      },
    );

    runAllowSignalWritesContext((): void => {
      for (let i = 0, l = futureSetAfter.length; i < l; i++) {
        const [signal, value]: IFutureSet = futureSetAfter[i];
        signal.set(value);
      }
    }, true);

    unsubscribeOfSignals = debounceMicrotaskObservable(signalsChange$)((): void => {
      unsubscribeOfSignals();
      update();
    });
  };

  update();

  return (): void => {
    unsubscribeOfSignals();
  };
}
