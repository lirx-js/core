export interface ISignalToObservableOptions {
  emitCurrentValue?: boolean; // (default: true)
  debounce?: boolean; // (default: true)
}
