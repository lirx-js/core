import { ISignalOptions } from '../signal/signal-options.type';

export interface IComputedOptions<GValue> extends ISignalOptions<GValue> {
}
