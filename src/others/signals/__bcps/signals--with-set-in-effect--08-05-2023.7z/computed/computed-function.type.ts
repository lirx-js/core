export interface IComputedFunction<GValue> {
  (): GValue;
}
