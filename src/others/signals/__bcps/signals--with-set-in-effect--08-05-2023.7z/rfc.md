RP: https://en.wikipedia.org/wiki/Reactive_programming
RFC: https://github.com/angular/angular/discussions/49685

