export interface IEffectOptions {
  allowSignalWrites?: boolean; // (default: false)
}
