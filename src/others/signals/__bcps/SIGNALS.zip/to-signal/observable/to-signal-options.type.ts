export interface IToSignalOptions<GInitialValue> {
  initialValue: GInitialValue;
}
