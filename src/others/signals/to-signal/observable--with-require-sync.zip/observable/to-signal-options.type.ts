export interface IToSignalOptionsWithInitialValue<GInitialValue> {
  initialValue: GInitialValue;
  requireSync?: false;
}

export interface IToSignalOptionsWithRequireSync {
  requireSync: true;
}


/*-----*/

export interface IToSignalOptionsNormalized<GInitialValue> {
  initialValue: GInitialValue | undefined;
  requireSync: boolean;
}

export type IToSignalOptions<GInitialValue> =
  | IToSignalOptionsWithInitialValue<GInitialValue>
  | IToSignalOptionsWithRequireSync
  | undefined
;

export function normalizeToSignalOptions<GInitialValue>(
  options: IToSignalOptions<GInitialValue>,
): IToSignalOptionsNormalized<GInitialValue> {
  if (options === void 0) {
    return {
      initialValue: void 0,
      requireSync: true,
    };
  } else {
    if ('initialValue' in options) {
      if (
        (options.requireSync === void 0)
        || (options.requireSync === false)
      ) {
        return {
          initialValue: options.initialValue,
          requireSync: false,
        };
      } else {
        throw new TypeError(`If "initialValue" is provided, then "requireSync" must be omit or false.`);
      }
    } else {
      if (options.requireSync === true) {
        return {
          initialValue: void 0,
          requireSync: true,
        };
      } else {
        throw new TypeError(`If "initialValue" is not provided, then "requireSync" must true.`);
      }
    }
  }
}
