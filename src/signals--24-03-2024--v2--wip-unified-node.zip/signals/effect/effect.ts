import {
  EFFECT_CONTEXT,
  effectContextRunInContext,
  effectContextStop,
  IEffectContext,
} from '../internal/effect.private';
import { getCurrentReactiveNodeObserver } from '../internal/reactive-context.private';
import { IEffetFunction } from './types/effet-function.type';
import { IUnsubscribeOfEffect } from './types/unsubscribe-of-effect.type';

export function effect(effectFunction: IEffetFunction): IUnsubscribeOfEffect {
  if (getCurrentReactiveNodeObserver() !== undefined) {
    throw new Error('Cannot create an effect in this context.');
  }

  const context: IEffectContext = Object.create(EFFECT_CONTEXT);
  context.effectFunction = effectFunction;

  effectContextRunInContext(context);

  return (): void => {
    effectContextStop(context);
  };
}
