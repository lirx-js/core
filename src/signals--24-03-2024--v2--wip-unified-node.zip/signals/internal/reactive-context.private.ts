/** REACTIVE NOTIFIER **/

/* TYPES */

/* FUNCTIONS */

/** REACTIVE NODE **/

/* TYPES */

const REACTIVE_NODE_STATE_FRESH = 0;
const REACTIVE_NODE_STATE_DIRTY = 1;
const REACTIVE_NODE_STATE_OUTDATED = 2;

type IReactiveNodeState =
  | typeof REACTIVE_NODE_STATE_FRESH
  | typeof REACTIVE_NODE_STATE_DIRTY
  | typeof REACTIVE_NODE_STATE_OUTDATED;

export interface IReactiveNode {
  state: IReactiveNodeState;
  observers: Set<IReactiveNode>; // list if nodes observing this node
  observed: Set<IReactiveNode>; // list if nodes observed by this node
  dirtyObserved: IReactiveNode[]; // list if dirty nodes observed by this node
}

type IOptionalReactiveNode = IReactiveNode | undefined;

export const REACTIVE_NODE: IReactiveNode = {
  state: REACTIVE_NODE_STATE_OUTDATED,
  observers: undefined as any,
  observed: undefined as any,
  dirtyObserved: undefined as any,
};

/* CURRENT */

let currentObserver: IOptionalReactiveNode = undefined;

// export function getCurrentReactiveNode(): IOptionalReactiveNode {
//   return currentReactiveNode;
// }

export function markReactiveNodeAsObservedByCurrentObserver(observed: IReactiveNode): void {
  if (currentObserver !== undefined) {
    bindReactiveNodes(currentObserver, observed);
  }
}

export function runReactiveContext<GReturn>(
  observer: IReactiveNode,
  callback: () => GReturn,
): GReturn {
  // TODO ensure no notifiers and outdated
  const previousObserver: IOptionalReactiveNode = currentObserver;
  currentObserver = observer;
  try {
    return callback();
  } finally {
    currentObserver = previousObserver;
  }
}

export function preventSignalWriteInSignalContext(): void {
  if (currentObserver !== undefined) {
    throw new Error('The signal cannot be written is this node.');
  }
}

/* FUNCTIONS */

export function initReactiveNode(node: IReactiveNode): void {
  node.observers = new Set<IReactiveNode>();
  node.observed = new Set<IReactiveNode>();
  node.dirtyObserved = [];
}

export function bindReactiveNodes(observer: IReactiveNode, observed: IReactiveNode): void {
  if (!observer.observed.has(observed)) {
    observer.observed.add(observed);
    observed.observers.add(observer);
  }
}

export function unbindReactiveNodes(observer: IReactiveNode, observed: IReactiveNode): void {
  // console.assert(observer.observed.has(observed));
  // console.assert(observed.observers.has(observer));
  // console.assert(!observer.dirtyObserved.includes(observed));

  observer.observed.delete(observed);
  observed.observers.delete(observer);
}

export function markReactiveNodeObserversAsDirty(observed: IReactiveNode): void {
  observed.observers.forEach((observer: IReactiveNode): void => {
    markReactiveNodeAsDirty(observer, observed);
  });
}

export function markReactiveNodeObserversAsOutdated(observed: IReactiveNode): void {
  observed.observers.forEach((observer: IReactiveNode): void => {
    markReactiveNodeAsOutdated(observer);
  });
}

export function markReactiveNodeAsDirty(observer: IReactiveNode, observed: IReactiveNode): void {
  // console.assert(observer.state !== REACTIVE_NODE_STATE_OUTDATED);
  const _markReactiveNodeObserversAsDirty: boolean = observer.state === REACTIVE_NODE_STATE_FRESH;

  observer.state = REACTIVE_NODE_STATE_DIRTY;
  observer.dirtyObserved.push(observed);

  if (_markReactiveNodeObserversAsDirty) {
    markReactiveNodeObserversAsDirty(observer);
  }
}

export function markReactiveNodeAsOutdated(node: IReactiveNode): void {
  // console.assert(node.state !== REACTIVE_NODE_STATE_OUTDATED);
  const _markReactiveNodeObserversAsDirty: boolean = node.state === REACTIVE_NODE_STATE_FRESH;

  node.state = REACTIVE_NODE_STATE_OUTDATED;
  node.dirtyObserved = [];

  node.observed.forEach((observed: IReactiveNode): void => {
    unbindReactiveNodes(node, observed);
  });

  if (_markReactiveNodeObserversAsDirty) {
    markReactiveNodeObserversAsDirty(node);
  }
}

export function shouldReactiveNodeRun(node: IReactiveNode): boolean {
  if (node.state === REACTIVE_NODE_STATE_DIRTY) {
    node.dirtyNotifiers.forEach(() => {});
  } else {
    return node.state === REACTIVE_NODE_STATE_OUTDATED;
  }
}
