import { SIGNAL } from '../signal/signal.symbol';
import { IReadonlySignal } from '../signal/types/readonly-signal.type';
import { ISignalUpdateFunctionCallback } from '../signal/types/signal-update-function-callback.type';
import { ERRORED, UNSET } from './computed.private';
import {
  IReactiveNode,
  markReactiveContextChangesSignalerAsChanged,
  markReactiveNodeAsObservedByCurrentObserver,
  preventSignalWriteInSignalContext,
} from './reactive-context.private';
import { ISignalNode, SIGNAL_NODE } from './signal.private';

/* NODE */

export interface IFallibleNode<GValue> extends ISignalNode<GValue> {
  error: unknown;
}

export const FALLIBLE_NODE: IFallibleNode<unknown> = {
  ...SIGNAL_NODE,
  error: undefined,
};

/* GET */

export type IFallibleGetNode<GValue> = Pick<IFallibleNode<GValue>, 'value' | 'error'> &
  IReactiveNode;

export function fallibleGet<GValue>(node: IFallibleGetNode<GValue>): GValue {
  markReactiveNodeAsObservedByCurrentObserver(node);
  if (node.value === UNSET) {
    throw new Error('Unset.');
  } else if (node.value === ERRORED) {
    throw node.error;
  }
  return node.value;
}

/* SET */

export type IFallibleSetNode<GValue> = Pick<IFallibleNode<GValue>, 'value' | 'error' | 'equal'> &
  IReactiveNode;

export function fallibleSet<GValue>(
  node: IFallibleSetNode<GValue>,
  value: GValue,
  error?: unknown,
): void {
  preventSignalWriteInSignalContext();

  if (
    node.value === UNSET ||
    node.value === ERRORED ||
    value === ERRORED ||
    !node.equal(value, node.value)
  ) {
    node.value = value;
    node.error = error;
    markReactiveContextChangesSignalerAsChanged(node);
  }
}

export type IFallibleThrowNode<GValue> = IFallibleSetNode<GValue>;

export function fallibleThrow<GValue>(node: IFallibleThrowNode<GValue>, error: unknown): void {
  fallibleSet<GValue>(node, ERRORED, error);
}

export type IFallibleUpdateNode<GValue> = IFallibleSetNode<GValue>;

export function fallibleUpdate<GValue>(
  node: IFallibleUpdateNode<GValue>,
  updateFunction: ISignalUpdateFunctionCallback<GValue>,
): void {
  let value: GValue;
  let error: unknown;

  try {
    value = updateFunction(node.value);
  } catch (_error: unknown) {
    value = ERRORED;
    error = _error;
  }

  if (value === ERRORED) {
    fallibleThrow<GValue>(node, error);
  } else {
    fallibleSet<GValue>(node, value);
  }
}

/* AS READONLY */

export type IFallibleAsReadonlyNode<GValue> = Pick<IFallibleNode<GValue>, 'readonlySignal'> &
  IFallibleGetNode<GValue>;

export function fallibleAsReadonly<GValue>(
  node: IFallibleAsReadonlyNode<GValue>,
): IReadonlySignal<GValue> {
  if (node.readonlySignal === undefined) {
    const readonlySignal: IReadonlySignal<GValue> = (): GValue => fallibleGet<GValue>(node);
    readonlySignal[SIGNAL] = node;
    node.readonlySignal = readonlySignal;
  }
  return node.readonlySignal;
}
