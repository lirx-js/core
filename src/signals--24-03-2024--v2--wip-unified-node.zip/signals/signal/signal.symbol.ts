export const SIGNAL = Symbol('SIGNAL');
