export interface IComputationFunction<GValue> {
  (): GValue;
}
