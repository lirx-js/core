import { fallible } from './fallible';

describe('fallible', () => {
  it('should have correct initial value', () => {
    const a = fallible(1);
    expect(a()).toBe(1);
  });

  it('should throw if no initial value', () => {
    const a = fallible();
    expect(() => a()).toThrow();
  });

  it('should have correct updated value', () => {
    const a = fallible(1);
    expect(a()).toBe(1);

    a.set(2);
    expect(a()).toBe(2);
  });

  it('should throw if thrown', () => {
    const a = fallible(1);
    expect(a()).toBe(1);

    const error = new Error();
    a.throw(error);
    expect(() => a()).toThrow(error);

    a.set(2);
    expect(a()).toBe(2);
  });
});
